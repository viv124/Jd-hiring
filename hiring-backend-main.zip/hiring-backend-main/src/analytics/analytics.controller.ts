import { Controller, Get } from '@nestjs/common';
import { AnalyticsService } from './analytics.service';
import { ApiTags } from '@nestjs/swagger';
import { ResponseError, ResponseSuccess } from 'src/common/dto';

@ApiTags('Analytics-dashboard')
@Controller('analytics')
export class AnalyticsController {
  constructor(private readonly analyticsService: AnalyticsService) {}

  // admin dashboard
  @Get('admin-dashboard')
  async getAdminDashboard() {
    const result = await this.analyticsService.getAdminDashboard();
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @Get('employee-analytics')
  async getEmployeeCountByRole() {
    const result = await this.analyticsService.getEmployeeCounts();
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }
}
