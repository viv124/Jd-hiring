import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from 'src/database/database.service';

@Injectable()
export class AnalyticsService {
  private readonly logger = new Logger(AnalyticsService.name);

  constructor(private readonly databaseService: DatabaseService) {}

  async getAdminDashboard() {
    try {
      const totalActiveJobDescriptions =
        await this.databaseService.jobDescription.count({
          where: {
            isActive: true,
            deletedAt: null,
          },
        });

      const totalInactiveJobDescriptions =
        await this.databaseService.jobDescription.count({
          where: {
            isActive: false,
            deletedAt: null,
          },
        });

      const activeCandidates = await this.databaseService.user.count({
        where: {
          role: 'CANDIDATE',
          isApproved: true,
        },
      });
      const activeEmployees = await this.databaseService.user.count({
        where: {
          role: { in: ['STAFF', 'RECRUITER', 'ADMIN'] },
          isApproved: true,
        },
      });
      return {
        success: true,
        message: 'Admin dashboard data fetched successfully.',
        data: {
          totalActiveJobDescriptions,
          totalInactiveJobDescriptions,
          activeCandidates,
          activeEmployees,
        },
      };
    } catch (error) {
      this.logger.error(error);
      return {
        success: false,
        message: 'Error fetching admin dashboard',
        data: [],
      };
    }
  }
  async getEmployeeCounts() {
    try {
      const counts = await this.databaseService.user.groupBy({
        by: ['role', 'isApproved'],
        _count: {
          role: true,
        },
      });

      const result = {
        total: 0,
        totalActive: 0,
        totalAdmin: 0,
        totalRecruiter: 0,
      };

      counts.forEach(({ role, isApproved, _count }) => {
        if (role === 'ADMIN' || role === 'STAFF' || role === 'RECRUITER') {
          result.total += _count.role;

          if (isApproved) {
            result.totalActive += _count.role;
          }
        }

        if (role === 'ADMIN') {
          result.totalAdmin += _count.role;
        }

        if (role === 'RECRUITER') {
          result.totalRecruiter += _count.role;
        }
      });

      return {
        success: true,
        message: 'Employee counts fetched successfully',
        data: result,
      };
    } catch (error) {
      this.logger.error(error);
      return {
        success: false,
        message: error,
        data: null,
      };
    }
  }
}
