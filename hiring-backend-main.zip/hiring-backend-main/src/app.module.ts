import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { UserModule } from './user/user.module';
import { GoogleAuthModule } from './google-auth/google-auth.module';
import { PassportModule } from '@nestjs/passport';
import { AnalyticsModule } from './analytics/analytics.module';
import { JobDescriptionModule } from './job-description/job-description.module';

@Module({
  imports: [
    UserModule,
    GoogleAuthModule,
    PassportModule,
    AnalyticsModule,
    JobDescriptionModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
