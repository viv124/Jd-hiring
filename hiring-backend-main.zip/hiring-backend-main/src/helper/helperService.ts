import * as crypto from 'crypto';

export class HelperService {
  optGenerate(): string {
    // Generate 4 random bytes (32 bits) to get enough entropy
    const randomBytes = crypto.randomBytes(4);

    // Convert the random bytes to an integer and ensure it falls within the 6-digit range
    const otp = (randomBytes.readUInt32BE(0) % 900000) + 100000;

    // Return the OTP as a string
    return otp.toString();
  }
}

const helperService = new HelperService();
export default helperService;

export const S3_FOLDER = {
  JOB_DESCRIPTION: 'JOB_DESCRIPTION',
  USER_PROFILE: 'USER_PROFILE',
  COMPANY_LOGO: 'COMPANY_LOGO',
  VIDEO: 'VIDEO',
  IMAGE: 'IMAGE',
  RESUME: 'RESUME',
};
