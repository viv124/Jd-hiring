import { S3Client } from '@aws-sdk/client-s3';

export const s3Client = new S3Client({
  endpoint: process.env.SUPABASE_S3_ENDPOINT, // e.g. https://zncwzadfvhjioheezbob.supabase.co/storage/v1/s3
  region: 'us-east-1',
  credentials: {
    accessKeyId: process.env.SUPABASE_S3_KEY as string,
    secretAccessKey: process.env.SUPABASE_S3_SECRET as string,
  },
  forcePathStyle: true,
});
