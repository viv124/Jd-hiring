import {
  Injectable,
  BadRequestException,
  InternalServerErrorException,
} from '@nestjs/common';
import { DeleteObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { s3Client } from 'src/config/aws.config';
import { Upload } from '@aws-sdk/lib-storage';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';

@Injectable()
export class S3Service {
  private readonly bucketName = process.env.SUPABASE_PUBLIC_BUCKET_NAME;
  private readonly privateBucketName = process.env.SUPABASE_PRIVATE_BUCKET_NAME;

  async uploadVideo(file: Express.Multer.File): Promise<string> {
    if (!file) {
      throw new BadRequestException('No video file provided');
    }

    const key = `videos/${Date.now()}-${file.originalname}`;

    // Stream the file to S3 for large uploads
    const upload = new Upload({
      client: s3Client,
      params: {
        Bucket: this.bucketName,
        Key: key,
        Body: file.stream || file.buffer, // Prefer stream if available
        ContentType: file.mimetype,
      },
    });

    await upload.done();
    return key;
  }
  async uploadImage(
    file: Express.Multer.File,
    folder: string,
    privateBucket: boolean = false,
  ): Promise<string> {
    if (!file) {
      throw new BadRequestException('No image file provided');
    }

    const key = `${folder}/${Date.now()}-${file.originalname}`;

    const upload = new Upload({
      client: s3Client,
      params: {
        Bucket: privateBucket ? this.privateBucketName : this.bucketName,
        Key: key,
        Body: file.stream || file.buffer,
        ContentType: file.mimetype,
      },
    });

    await upload.done();
    return key;
  }

  async getSignedUrl(key: string): Promise<string> {
    const command = new GetObjectCommand({
      Bucket: this.privateBucketName,
      Key: key,
    });

    const data = getSignedUrl(s3Client, command, { expiresIn: 3600 });
    return data;
  }

  async deleteFile(key: string, bucketNameParam?: string): Promise<void> {
    try {
      const command = new DeleteObjectCommand({
        Bucket: bucketNameParam,
        Key: key,
      });

      await s3Client.send(command);
    } catch (error) {
      throw new InternalServerErrorException(
        'Failed to delete file from S3',
        error,
      );
    }
  }
}
