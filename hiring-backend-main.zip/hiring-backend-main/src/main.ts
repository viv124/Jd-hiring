import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';
import * as dotenv from 'dotenv';
import { AllExceptionsFilter } from './common/filters/all-exception.filter';
import { Logger, ValidationPipe } from '@nestjs/common';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';

dotenv.config();

async function bootstrap() {
  const logger = new Logger('main');
  const app = await NestFactory.create(AppModule);
  app.useGlobalPipes(new ValidationPipe({ transform: true })); // Enable validation
  app.useGlobalFilters(new AllExceptionsFilter());
  app.enableCors();

  if (process.env.NODE_ENV === 'DEVELOPMENT') {
    const config = new DocumentBuilder()
      .setTitle('JD')
      .setDescription('JD API Documentation')
      .setVersion('1.0')
      .addBearerAuth(
        { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' },
        'Authorization',
      )
      .build();
    const document = SwaggerModule.createDocument(app, config);
    SwaggerModule.setup('jd', app, document);
  }

  const port = process.env.PORT || 3000;
  await app.listen(port);
  const url = await app.getUrl();
  logger.log(`Server is running on ${url}`);
}
bootstrap();
