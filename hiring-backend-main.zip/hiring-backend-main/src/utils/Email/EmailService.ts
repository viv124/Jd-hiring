import { Injectable, Logger } from '@nestjs/common';
import * as nodemailer from 'nodemailer';
import { EmailUpdateDto } from 'src/user/dto/email-update.dto';

@Injectable()
export class EmailService {
  private readonly transporter: nodemailer.Transporter;
  private readonly logger = new Logger(EmailService.name);

  constructor() {
    this.transporter = nodemailer.createTransport({
      host: process.env.SMTP_HOST,
      port: parseInt(process.env.SMTP_PORT || '465', 10),
      secure: true, // true for 465, false for other ports
      auth: {
        user: process.env.SMTP_MAIL,
        pass: process.env.SMTP_PASSWORD,
      },
    });
  }

  async emailOTP(user: any, otp: string): Promise<any> {
    try {
      const mailOptions = {
        from: process.env.SMTP_MAIL,
        to: user.email,
        subject: `Your OTP Code - ${otp}`,
        html: `
      <div style="font-family: 'Arial', sans-serif; line-height: 1.6; color: #333; background-color: #f9f9f9; padding: 20px; border: 1px solid #ddd; border-radius: 10px; max-width: 600px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 20px;">
          <img src="https://via.placeholder.com/150?text=JD+HIRE" alt="JD Hire Logo" style="max-width: 150px; height: auto;">
        </div>
        <h2 style="color: #4A90E2; text-align: center;">Your One-Time Password (OTP)</h2>
        <p>Dear ${user.name ?? 'User'},</p>
        <p>Thank you for registering on JD Hire. To complete your registration, please use the following OTP:</p>
        <div style="text-align: center; margin: 30px 0;">
          <span style="display: inline-block; background: #4A90E2; color: #fff; font-size: 28px; font-weight: bold; letter-spacing: 8px; padding: 16px 32px; border-radius: 8px;">
            ${otp}
          </span>
        </div>
        <p>This OTP is valid for 10 minutes. Please do not share it with anyone.</p>
        <p>If you did not request this, please ignore this email.</p>
        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
        <p style="text-align: center; font-size: 14px; color: #333;">Best regards,<br><strong>The JD Hire Team</strong></p>
        <p style="text-align: center; font-size: 12px; color: #aaa; margin-top: 20px;">© ${new Date().getFullYear()} JD Hire. All rights reserved.</p>
      </div>
      `,
      };

      await this.transporter.sendMail(mailOptions);

      return {
        success: true,
        data: { message: 'OTP sent successfully.' },
      };
    } catch (error) {
      this.logger.error('Error sending OTP email', error);
      return {
        success: false,
        data: { message: 'Failed to send OTP.' },
      };
    }
  }

  sendInviteEmail(email: string, inviteLink: any) {
    try {
      const mailOptions = {
        from: process.env.SMTP_MAIL,
        to: email,
        subject: 'You are invited to join JD Hire!',
        html: `
          <div style="font-family: 'Arial', sans-serif; line-height: 1.6; color: #333; background-color: #f9f9f9; padding: 24px; border: 1px solid #ddd; border-radius: 10px; max-width: 600px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 20px;">
          <img src="https://via.placeholder.com/150?text=JD+HIRE" alt="JD Hire Logo" style="max-width: 150px; height: auto;">
        </div>
        <h2 style="color: #4A90E2; text-align: center;">Invitation to Join JD Hire</h2>
        <p>Dear User,</p>
        <p>You have been invited to join <strong>JD Hire</strong>! Click the button below to accept your invitation and get started:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${inviteLink}" style="display: inline-block; background: #4A90E2; color: #fff; font-size: 18px; font-weight: bold; padding: 14px 32px; border-radius: 8px; text-decoration: none;">
            Accept Invitation
          </a>
        </div>
        <p>If you did not expect this invitation, you can safely ignore this email.</p>
        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
        <p style="text-align: center; font-size: 14px; color: #333;">Best regards,<br><strong>The JD Hire Team</strong></p>
        <p style="text-align: center; font-size: 12px; color: #aaa; margin-top: 20px;">© ${new Date().getFullYear()} JD Hire. All rights reserved.</p>
          </div>
        `,
      };

      this.transporter.sendMail(mailOptions);

      return {
        success: true,
        data: { message: 'Invitation sent successfully.' },
      };
    } catch (error) {
      this.logger.error('Error sending invitation email', error);
      return {
        success: false,
        data: { message: 'Failed to send invitation email.' },
      };
    }
  }

  async sendVerificationEmail(email: string, name: string, token: string) {
    try {
      const url = `${process.env.FRONTEND_REDIRECT_URL}/password-reset/${token}`;
      const currentYear = new Date().getFullYear();

      const mailOptions = {
        from: process.env.SMTP_MAIL,
        to: email,
        subject: 'JD Hire Password Reset Request',
        html: `
          <div style="font-family: Arial, sans-serif; background: #f9f9f9; color: #333; padding: 24px; border-radius: 10px; max-width: 600px; margin: 0 auto; border: 1px solid #ddd;">
            <div style="text-align: center; margin-bottom: 20px;">
              <img src="https://via.placeholder.com/150?text=JD+HIRE" alt="JD Hire Logo" style="max-width: 150px; height: auto;">
            </div>
            <h2 style="color: #4A90E2; text-align: center;">Password Reset Request</h2>
            <p>Dear ${name || 'User'},</p>
            <p>We received a request to reset your JD Hire account password. Click the button below to reset your password:</p>
            <div style="text-align: center; margin: 30px 0;">
              <a href="${url}" style="display: inline-block; background: #4A90E2; color: #fff; font-size: 16px; font-weight: bold; padding: 12px 28px; border-radius: 8px; text-decoration: none;">
                Reset Password
              </a>
            </div>
            <p>If you did not request this, you can safely ignore this email.</p>
            <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
            <p style="text-align: center; font-size: 14px; color: #333;">Best regards,<br><strong>The JD Hire Team</strong></p>
            <p style="text-align: center; font-size: 12px; color: #aaa; margin-top: 20px;">© ${currentYear} JD Hire. All rights reserved.</p>
          </div>
        `,
      };

      await this.transporter.sendMail(mailOptions);

      return {
        success: true,
        data: { message: 'Verification email sent successfully.' },
      };
    } catch (error) {
      this.logger.error('Error sending verification email:', error);
      return {
        success: false,
        data: { message: 'Failed to send verification email.' },
      };
    }
  }

  async sendEmailUpdateLink(emailUpdateDto: EmailUpdateDto, token: string) {
    try {
      const url = `${process.env.FRONTEND_REDIRECT_URL}/email-update/${token}`;
      const currentYear = new Date().getFullYear();

      const mailOptions = {
        from: process.env.SMTP_MAIL,
        to: [emailUpdateDto.oldEmail, emailUpdateDto.newEmail],
        subject: 'JD Hire Email Update Request',
        html: `
          <div style="font-family: Arial, sans-serif; background: #f9f9f9; color: #333; padding: 24px; border-radius: 10px; max-width: 600px; margin: 0 auto; border: 1px solid #ddd;">
        <div style="text-align: center; margin-bottom: 20px;">
          <img src="https://via.placeholder.com/150?text=JD+HIRE" alt="JD Hire Logo" style="max-width: 150px; height: auto;">
        </div>
        <h2 style="color: #4A90E2; text-align: center;">Email Update Request</h2>
        <p>Dear User,</p>
        <p>We received a request to update your JD Hire account email from <strong>${emailUpdateDto.oldEmail}</strong> to <strong>${emailUpdateDto.newEmail}</strong>. Click the button below to confirm your new email address:</p>
        <div style="text-align: center; margin: 30px 0;">
          <a href="${url}" style="display: inline-block; background: #4A90E2; color: #fff; font-size: 16px; font-weight: bold; padding: 12px 28px; border-radius: 8px; text-decoration: none;">
            Confirm Email Update
          </a>
        </div>
        <p>If you did not request this, you can safely ignore this email.</p>
        <hr style="border: none; border-top: 1px solid #ddd; margin: 30px 0;">
        <p style="text-align: center; font-size: 14px; color: #333;">Best regards,<br><strong>The JD Hire Team</strong></p>
        <p style="text-align: center; font-size: 12px; color: #aaa; margin-top: 20px;">© ${currentYear} JD Hire. All rights reserved.</p>
          </div>
        `,
      };

      await this.transporter.sendMail(mailOptions);

      return {
        success: true,
        data: { message: 'Email update link sent successfully.' },
      };
    } catch (error) {
      this.logger.error('Error sending email update link:', error);
      return {
        success: false,
        data: { message: 'Failed to send email update link.' },
      };
    }
  }
}
