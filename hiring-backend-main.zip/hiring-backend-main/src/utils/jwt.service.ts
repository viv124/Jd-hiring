import { Role } from '@prisma/client';
import * as jwt from 'jsonwebtoken';
import { EmailUpdateDto } from 'src/user/dto/email-update.dto';

export function createToken(name: string, email: string, role: Role) {
  const expiresIn = process.env.JWT_EXPIRES_IN || '1h';
  const secretKey = process.env.JWT_SECRET_KEY || 'defaultSecretKey';

  const userInfo = { name: name, email: email, role: role };
  const token = jwt.sign(userInfo, secretKey, { expiresIn });

  return {
    expires_in: expiresIn,
    access_token: token,
  };
}

export function decodeToken(token: string) {
  const secretKey = process.env.JWT_SECRET_KEY || 'defaultSecretKey';

  const verified = jwt.verify(token, secretKey);

  return verified;
}
export function generatePasswordChangeToken(email: string) {
  const passwordUpdatePayload = { email };
  const jwtSecret = process.env.PASSWORD_CHANGE_SECRET_KEY as string;

  return jwt.sign(passwordUpdatePayload, jwtSecret, {
    expiresIn: '24h',
  });
}

// generate emailUpdate token
export function generateEmailUpdateToken(emailUpdateDto: EmailUpdateDto) {
  const jwtSecret = process.env.EMAIL_UPDATE_SECRET_KEY as string;

  const emailToken = jwt.sign(emailUpdateDto, jwtSecret, {
    expiresIn: '30m',
  });

  return emailToken;
}
