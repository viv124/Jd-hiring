import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Put,
  Query,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { UserService } from './user.service';
import {
  ApiBearerAuth,
  ApiBody,
  ApiConsumes,
  ApiOperation,
  ApiTags,
} from '@nestjs/swagger';
import { CreateUserDto, InviteUserDto } from './dto/create.user.dto';
import { ResponseError, ResponseSuccess } from 'src/common/dto';
import { LoginUserDto } from './dto/user.login.dto';
import { AuthGuard } from 'src/common/authentication/auth.guard';
import { VerifyRegistrationOtpDto } from './dto/verifiedRegister.dto';
import { UpdatePasswordDto } from './dto/updatePassword.dto';
import { ForgotPasswordDto, ResetPasswordDto } from './dto/forgot-password.dto';
import { PasswordChangeTokenGuard } from 'src/common/authentication/passwordChange.auth.gaurd';
import { EmailUpdateDto, EmailupdateDtoInput } from './dto/email-update.dto';
import { EmailUpdateTokenGuard } from 'src/common/authentication/emailUpdate.guard';
import { UserPaginationDto } from './dto/user.pagination.dto';
import { UpdateUserDto } from './dto/update.profile.dto';
import { UploadResumeDto } from './dto/upload-resume.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { RoleType, Roles, RolesGuard } from 'src/common/roles';

@ApiTags('User Module')
@Controller('user')
export class UserController {
  constructor(private readonly userService: UserService) {}

  @Post('register')
  @ApiOperation({ summary: 'Register a new user' })
  async registerUser(@Body() createUserDto: CreateUserDto) {
    const result = await this.userService.registerUser(createUserDto);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(
      result.data,
      result.message,
      result.statusCode,
    ).getResponse();
  }

  @Post('register/verify-otp')
  @ApiOperation({ summary: 'Verify OTP for user registration' })
  async verifyRegistrationOtp(
    @Body() verifyRegistrationOtpDto: VerifyRegistrationOtpDto,
  ) {
    const result = await this.userService.emailVerify(verifyRegistrationOtpDto);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  //Login
  @Post('/login')
  @ApiOperation({ summary: 'Login user' })
  async loginUser(@Body() loginUserDto: LoginUserDto) {
    const result = await this.userService.loginUser(loginUserDto);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Get('/profile')
  @ApiOperation({ summary: 'Get user profile' })
  getProfile(@Req() req: any) {
    const user = req.user;
    return new ResponseSuccess(
      user,
      'Profile fetched successfully.',
    ).getResponse();
  }

  // Update user profile
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Patch('/profile/update')
  @ApiOperation({ summary: 'Update user profile' })
  async updateProfile(
    @Req() req: any,
    @Body() updateProfileDto: CreateUserDto,
  ) {
    const userId = req.user.id;
    const result = await this.userService.updateProfile(
      userId,
      updateProfileDto,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  //update user email
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Patch('/profile/update-email')
  @ApiOperation({ summary: 'Update user email' })
  async updateEmail(
    @Req() req: any,
    @Body() updateEmailDto: EmailupdateDtoInput,
  ) {
    const emailUpdateDto: EmailUpdateDto = {
      id: req.user.id,
      oldEmail: req.user.email,
      newEmail: updateEmailDto.newemail,
    };

    const result = await this.userService.updateEmail(emailUpdateDto);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  // verify email update token
  @ApiBearerAuth('Authorization')
  @UseGuards(EmailUpdateTokenGuard)
  @Get('/profile/verify-email-update')
  @ApiOperation({ summary: 'Verify email update token' })
  async verifyEmailUpdateToken(@Req() req: any) {
    const result = await this.userService.verifyEmailUpdateToken(req.user);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  // update user password
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Patch('/profile/update-password')
  @ApiOperation({ summary: 'Update user password' })
  async updatePassword(
    @Req() req: any,
    @Body() updatePasswordDto: UpdatePasswordDto,
  ) {
    const result = await this.userService.updatePassword(
      req.user,
      updatePasswordDto,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  //forgot password
  @Post('/forgot-password')
  @ApiOperation({ summary: 'Forgot password' })
  async forgotPassword(@Body() forgotPasswordDto: ForgotPasswordDto) {
    const result = await this.userService.forgotPassword(
      forgotPasswordDto.email,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @ApiBearerAuth('Authorization')
  @UseGuards(PasswordChangeTokenGuard)
  @ApiOperation({ summary: 'Update password using token' })
  @Post('/forgot/verify-password')
  async resetPassword(
    @Body() resetPasswordDto: ResetPasswordDto,
    @Req() req: any,
  ) {
    const result = await this.userService.resetPassword(
      req.user.email,
      resetPasswordDto.newPassword,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  //invite user
  @Post('/invite')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.ADMIN)
  @ApiOperation({ summary: 'Invite a user' })
  @ApiOperation({ summary: 'Invite staff via Google login' })
  async inviteUser(@Body() inviteUserDto: InviteUserDto) {
    const result = await this.userService.inviteUser(inviteUserDto);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Get('/all')
  @ApiOperation({ summary: 'Get all users' })
  async getAllUsers(@Query() query: UserPaginationDto, @Req() req: any) {
    const result = await this.userService.getAllUsers(req.user, query);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  // update by userId
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.ADMIN)
  @Patch('/:userId')
  @ApiOperation({ summary: ' ADMIN IS UPDATE  own staff-user by id' })
  async updateUserById(
    @Param('userId') userId: string,
    @Body() updateUserDto: UpdateUserDto,
  ) {
    const result = await this.userService.updateUserById(userId, updateUserDto);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  //delete user
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.ADMIN)
  @Delete('/:userId')
  @ApiOperation({ summary: ' ADMIN IS DELETE own staff-user by id' })
  async deleteUserById(@Param('userId') userId: string) {
    const result = await this.userService.deleteUserById(userId);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @Post('resume/upload')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.CANDIDATE)
  @ApiBearerAuth('Authorization')
  @ApiOperation({ summary: 'Upload a resume' })
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Upload resume file with title',
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string', example: 'Backend Resume' },
        file: {
          type: 'string',
          format: 'binary',
        },
      },
      required: ['title', 'file'],
    },
  })
  async uploadResume(
    @Req() req: any,
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: UploadResumeDto,
  ) {
    const result = await this.userService.uploadResume(req.user.id, file, dto);
    if (!result.success) {
      return new ResponseError(result, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @Put('resume/:resumeId')
  @UseGuards(AuthGuard)
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.CANDIDATE)
  @ApiBearerAuth('Authorization')
  @ApiOperation({ summary: 'update a resume' })
  @UseInterceptors(FileInterceptor('file'))
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'update resume file with title',
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string', example: 'Backend Resume' },
        file: {
          type: 'string',
          format: 'binary',
        },
      },
      required: ['title', 'file'],
    },
  })
  async updateResume(
    @Req() req: any,
    @Param('resumeId') resumeId: string,
    @UploadedFile() file: Express.Multer.File,
    @Body() dto: UploadResumeDto,
  ) {
    const result = await this.userService.updateResume(
      req.user.id,
      file,
      dto,
      resumeId,
    );
    if (!result.success) {
      return new ResponseError(result, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Get('/resume')
  @ApiOperation({ summary: 'Get resume' })
  async getResume(@Req() req: any) {
    const result = await this.userService.getResume(req.user.id);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  // delete resume
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @Delete('/resume/:resumeId')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.CANDIDATE, RoleType.ADMIN)
  @ApiOperation({ summary: 'Delete resume' })
  async deleteResume(@Req() req: any, @Param('resumeId') resumeId: string) {
    const result = await this.userService.deleteResume(req.user.id, resumeId);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }
}
