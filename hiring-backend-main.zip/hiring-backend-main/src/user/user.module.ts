import { Module } from '@nestjs/common';
import { UserService } from './user.service';
import { UserController } from './user.controller';
import { DatabaseModule } from 'src/database/database.module';
import { JwtService } from '@nestjs/jwt';
import { EmailService } from 'src/utils/Email/EmailService';
import { S3Service } from 'src/s3/s3.service';

@Module({
  imports: [DatabaseModule],
  controllers: [UserController],
  providers: [UserService, JwtService, EmailService, S3Service],
})
export class UserModule {}
