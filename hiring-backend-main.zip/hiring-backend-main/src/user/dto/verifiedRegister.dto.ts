import { IsEmail, IsNotEmpty, IsNumber, Max, Min } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class VerifyRegistrationOtpDto {
  @ApiProperty({
    example: 'user@example.com',
    description: 'The email address of the user',
  })
  @IsEmail({}, { message: 'Please provide a valid email address' })
  @IsNotEmpty({ message: 'Email is required' })
  email: string;

  @ApiProperty({
    example: 123456,
    description: '6-digit OTP sent to the user',
    minimum: 100000,
    maximum: 999999,
  })
  @IsNumber()
  @IsNotEmpty({ message: 'OTP is required' })
  @Min(100000, { message: 'OTP must be exactly 6 digits' })
  @Max(999999, { message: 'OTP must be exactly 6 digits' })
  otp: number;
}
