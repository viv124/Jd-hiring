import {
  IsEmail,
  IsEnum,
  IsNotEmpty,
  IsOptional,
  IsString,
  Matches,
  MinLength,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Role } from '@prisma/client';
export class CreateUserDto {
  @IsString()
  @IsEmail()
  @ApiProperty({ example: 'user.jd@yopmail.com', description: 'email' })
  email: string;

  @ApiProperty({ example: 'Password@123', description: 'New password' })
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(7, { message: 'Password must be at least 8 characters long' })
  @Matches(/[A-Z]/, {
    message: 'Password must contain at least one uppercase letter',
  })
  @Matches(/[!@#$&*]/, {
    message: 'Password must contain at least one special character',
  })
  @Matches(/\d/, { message: 'Password must contain at least one digit' })
  password: string;

  @IsString()
  @ApiProperty({ example: 'jd user', description: 'first name' })
  firstName: string;

  @IsString()
  @ApiProperty({ example: 'doe', description: 'last name' })
  lastName: string;

  @ApiProperty({
    enum: Role,
    example: 'ADMIN,STAFF,RECRUITER',
  })
  @IsEnum(Role, {
    message: 'Invalid Role. Must be one of: ADMIN,USER',
  })
  role: Role;

  @IsString()
  @IsOptional()
  otp?: string;
}

export class InviteUserDto {
  @IsString()
  @ApiProperty({ example: 'jd user', description: 'first name' })
  firstName: string;

  @IsString()
  @ApiProperty({ example: 'doe', description: 'last name' })
  lastName: string;

  @ApiProperty({
    enum: Role,
    example: 'ADMIN,STAFF,RECRUITER',
  })
  @IsEnum(Role, {
    message: 'Invalid Role. Must be one of: ADMIN,USER',
  })
  role: Role;

  @ApiProperty({ example: 'IT', description: 'department' })
  @IsString()
  @IsOptional()
  department?: string;

  @IsString()
  @IsEmail()
  @ApiProperty({ example: 'user.jd@yopmail.com', description: 'email' })
  email: string;
}
