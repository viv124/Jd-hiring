import { ApiPropertyOptional } from '@nestjs/swagger';
import { Role } from '@prisma/client';
import { Transform } from 'class-transformer';
import { IsArray, IsBoolean, IsEnum, IsOptional } from 'class-validator';
import { QueryRequestInput } from 'src/common/dto/pagination.dto';

export class UserPaginationDto extends QueryRequestInput {
  @ApiPropertyOptional({
    description: 'Comma-separated list of roles to filter',
    example: 'CANDIDATE,STAFF,RECRUITER',
    enum: Role,
    isArray: true,
  })
  @IsOptional()
  @Transform(({ value }) =>
    typeof value === 'string' ? value.split(',') : value,
  )
  @IsArray()
  @IsEnum(Role, { each: true, message: 'Invalid role provided' })
  roles?: Role[];

  @ApiPropertyOptional({
    type: Boolean,
    example: true,
    description: 'Filter users by active status',
  })
  @IsOptional()
  @IsBoolean()
  @Transform(({ value }) => value === 'true') // this converts "true"/"false" string to boolean
  isApproved?: boolean;
}
