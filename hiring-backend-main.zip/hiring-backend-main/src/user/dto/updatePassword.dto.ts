import { IsNotEmpty, Matches, MinLength } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class UpdatePasswordDto {
  @ApiProperty({ example: 'Password@123', description: 'New password' })
  @IsNotEmpty({ message: 'Password is required' })
  @MinLength(8, { message: 'Password must be at least 8 characters long' })
  @Matches(/[A-Z]/, {
    message: 'Password must contain at least one uppercase letter',
  })
  @Matches(/[!@#$&*]/, {
    message: 'Password must contain at least one special character',
  })
  @Matches(/\d/, { message: 'Password must contain at least one digit' })
  newPassword: string;

  @ApiProperty({ example: 'Password@123', description: 'New password' })
  @IsNotEmpty({ message: 'Password is required' })
  oldPassword: string;
}
