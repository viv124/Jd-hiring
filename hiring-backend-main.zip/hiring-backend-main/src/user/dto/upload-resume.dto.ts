import { IsString, IsOptional } from 'class-validator';

export class UploadResumeDto {
  @IsString()
  @IsOptional()
  title?: string;
}

export class UpdateResumeDto {
  @IsString()
  @IsOptional()
  title?: string;
}
