import { IsEmail, IsString } from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';

export class LoginUserDto {
  @IsString()
  @IsEmail()
  @ApiProperty({ example: 'user.jd@yopmail.com', description: 'email' })
  email: string;

  @IsString()
  @ApiProperty({ example: 'Password@123', description: 'password' })
  password: string;
}
