import { HttpStatus, Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from 'src/database/database.service';
import { CreateUserDto, InviteUserDto } from './dto/create.user.dto';
import * as bcrypt from 'bcryptjs';
import helperService, { S3_FOLDER } from 'src/helper/helperService';
import { EmailService } from 'src/utils/Email/EmailService';
import { LoginUserDto } from './dto/user.login.dto';
import {
  createToken,
  generateEmailUpdateToken,
  generatePasswordChangeToken,
} from 'src/utils/jwt.service';
import { VerifyRegistrationOtpDto } from './dto/verifiedRegister.dto';
import { UpdateProfileDto, UpdateUserDto } from './dto/update.profile.dto';
import { UpdatePasswordDto } from './dto/updatePassword.dto';
import { EmailUpdateDto } from './dto/email-update.dto';
import { UserPaginationDto } from './dto/user.pagination.dto';
import { UploadResumeDto } from './dto/upload-resume.dto';
import { S3Service } from 'src/s3/s3.service';

@Injectable()
export class UserService {
  private readonly logger = new Logger(UserService.name);
  constructor(
    private readonly databaseService: DatabaseService,
    private readonly emailService: EmailService,
    private readonly s3Service: S3Service,
  ) {}

  async registerUser(createUserDto: CreateUserDto) {
    try {
      const userCheck = await this.databaseService.user.findUnique({
        where: { email: createUserDto.email.toLowerCase(), deletedAt: null },
      });

      if (userCheck?.isVerified) {
        throw {
          name: 'badRequest',
          message: 'Email already registered.',
        };
      }

      const otp = helperService.optGenerate().toString();
      if (userCheck) {
        await this.updateUserOtp(userCheck.id, otp);
        await this.sendOtpEmail(userCheck, otp);
        return {
          success: true,
          message: 'OTP sent successfully.',
          data: {
            message: 'OTP sent successfully.',
          },
        };
      }
      await this.sendOtpEmail(createUserDto, otp);
      await this.createUser(createUserDto, otp);
      return {
        statusCode: HttpStatus.CREATED,
        success: true,
        message: 'Otp sent successfully',
        data: [],
      };
    } catch (error) {
      this.logger.error('Error in registerUser:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }
  async emailVerify(verifyRegistrationOtpDto: VerifyRegistrationOtpDto) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: {
          email: verifyRegistrationOtpDto.email.toLowerCase(),
          deletedAt: null,
        },
      });

      if (!user) {
        throw {
          name: 'notFound',
          message: 'User not found.',
        };
      }

      if (user.otp !== verifyRegistrationOtpDto.otp.toString()) {
        throw {
          name: 'badRequest',
          message: 'Invalid OTP.',
        };
      }

      await this.databaseService.user.update({
        where: { id: user.id },
        data: { isVerified: true, otp: null },
      });

      return {
        success: true,
        message: 'Email verified successfully.',
        data: [],
      };
    } catch (error) {
      this.logger.error('Error in emailVerify:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async loginUser(loginUserDto: LoginUserDto) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: { email: loginUserDto.email.toLowerCase(), deletedAt: null },
      });
      if (!user) {
        throw {
          name: 'badRequest',
          message: 'User not found.',
        };
      }
      if (!user.isVerified) {
        throw {
          name: 'badRequest',
          message: 'User is not verified.',
        };
      }
      const isPasswordMatch = await bcrypt.compare(
        loginUserDto.password,
        user?.password || '',
      );
      if (!isPasswordMatch) {
        throw {
          name: 'badRequest',
          message: 'Invalid password.',
        };
      }
      const accessToken = createToken(
        `${user.firstName} ${user.lastName}`,
        user.email,
        user.role,
      );
      this.logger.log(`User ${user.email} logged in successfully.`);
      return {
        success: true,
        message: 'Login successful.',
        data: accessToken,
      };
    } catch (error) {
      this.logger.error('Error in loginUser:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async updateProfile(userId: string, updateProfileDto: UpdateProfileDto) {
    try {
      const updatedUser = await this.databaseService.user.update({
        where: { id: userId },
        data: updateProfileDto,
      });
      if (!updatedUser) {
        throw {
          name: 'notFound',
          message: 'User not found.',
        };
      }
      this.logger.log(
        `User ${updatedUser.email} profile updated successfully.`,
      );
      return {
        success: true,
        message: 'Profile updated successfully.',
        data: updatedUser,
      };
    } catch (error) {
      this.logger.error('Error in updateProfile:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async updateEmail(emailUpdateDto: EmailUpdateDto) {
    try {
      const emailToken = generateEmailUpdateToken({
        id: emailUpdateDto.id,
        oldEmail: emailUpdateDto.oldEmail,
        newEmail: emailUpdateDto.newEmail,
      });

      // send email with the token
      const emailSent = await this.emailService.sendEmailUpdateLink(
        emailUpdateDto,
        emailToken,
      );

      if (!emailSent) {
        throw {
          name: 'badRequest',
          message: 'Failed to send email.',
        };
      }
      this.logger.log(
        `Email update link sent to ${emailUpdateDto.oldEmail} and ${emailUpdateDto.newEmail}.`,
      );

      return {
        success: true,
        message: 'Email update link sent successfully.',
        data: [],
      };
    } catch (error) {
      this.logger.error('Error in updateEmail:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }
  async verifyEmailUpdateToken(user: any) {
    try {
      const updatedUser = await this.databaseService.user.update({
        where: { id: user.id, email: user.oldEmail },
        data: { email: user.newEmail },
      });
      if (!updatedUser) {
        throw {
          name: 'notFound',
          message: 'User not found or email already updated.',
        };
      }
      return {
        success: true,
        message: 'Email updated successfully.',
        data: [],
      };
    } catch (error) {
      this.logger.error('Error in verifyEmailUpdateToken:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async updatePassword(user: any, updatePasswordDto: UpdatePasswordDto) {
    try {
      const { oldPassword } = updatePasswordDto;
      const isPasswordMatch = await bcrypt.compare(oldPassword, user.password);
      if (!isPasswordMatch) {
        throw {
          name: 'badRequest',
          message: 'Old password is incorrect.',
        };
      }
      const hashedPassword = await this.generateHashedPassword(
        updatePasswordDto.newPassword,
      );
      const updatedUser = await this.databaseService.user.update({
        where: { id: user.id },
        data: { password: hashedPassword },
      });
      if (!updatedUser) {
        throw {
          name: 'notFound',
          message: 'User not found.',
        };
      }
      this.logger.log(
        `User ${updatedUser.email} password updated successfully.`,
      );
      return {
        success: true,
        message: 'Password updated successfully.',
        data: updatedUser,
      };
    } catch (error) {
      this.logger.error('Error in updatePassword:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async forgotPassword(email: string) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: { email: email.toLowerCase(), deletedAt: null },
      });
      if (!user) {
        throw {
          name: 'notFound',
          message: 'User not found.',
        };
      }
      const resetToken = generatePasswordChangeToken(user.email);
      const resetTokenExpiry = new Date();
      resetTokenExpiry.setHours(resetTokenExpiry.getHours() + 24); // 24-hour expiry

      await this.databaseService.user.update({
        where: { id: user.id },
        data: { resetToken: 'Bearer ' + resetToken, resetTokenExpiry },
      });
      const data = await this.emailService.sendVerificationEmail(
        user.email,
        `${user.firstName} ${user.lastName}`,
        resetToken,
      );
      if (!data.success) {
        throw { name: 'Bad Request', message: 'Failed to send email' };
      }
      this.logger.log(`Password reset email sent to ${user.email}`);
      return {
        success: true,
        message: 'Password reset email sent successfully.',
      };
    } catch (error) {
      this.logger.error('Error in forgotPassword:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async resetPassword(email: string, newPassword: string) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: { email, deletedAt: null },
      });

      if (!user) {
        throw { name: 'Unauthorized', message: 'User does not exist!' };
      }
      const hashedPassword = await this.generateHashedPassword(newPassword);

      const updatedUser = await this.databaseService.user.update({
        where: { id: user.id, isVerified: true, isApproved: true },
        data: {
          password: hashedPassword,
          resetToken: null,
          resetTokenExpiry: null,
        },
      });
      if (!updatedUser) {
        throw { name: 'Unauthorized', message: 'Failed to update password!' };
      }
      this.logger.log(`Password reset successfully for ${email}`);
      return {
        success: true,
        message: 'Password reset successfully.',
        data: [],
      };
    } catch (error) {
      this.logger.error('Error in resetPassword:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async inviteUser(inviteUserDto: InviteUserDto) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: { email: inviteUserDto.email.toLowerCase(), deletedAt: null },
      });

      if (user?.isVerified) {
        throw {
          name: 'badRequest',
          message: 'User already exists.',
        };
      }

      await this.databaseService.user.upsert({
        where: { email: inviteUserDto.email.toLowerCase() },
        update: {
          firstName: inviteUserDto.firstName,
          lastName: inviteUserDto.lastName,
          department: inviteUserDto.department,
          role: inviteUserDto.role,
        },
        create: {
          email: inviteUserDto.email.toLowerCase(),
          firstName: inviteUserDto.firstName,
          lastName: inviteUserDto.lastName,
          department: inviteUserDto.department,
          role: inviteUserDto.role,
          isVerified: false,
          isApproved: true,
        },
      });

      const inviteLink = process.env.GOOGLE_REDIRECT_URL;
      this.emailService.sendInviteEmail(inviteUserDto.email, inviteLink);
      this.logger.log(`Invitation sent to ${inviteUserDto.email}`);

      return {
        success: true,
        message: 'Invitation sent successfully.',
        data: [],
      };
    } catch (error) {
      this.logger.error('Error in inviteUser:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async getAllUsers(user: any, query: UserPaginationDto) {
    try {
      const { pageNo = 1, limit = 10, queryString } = query;
      const searchQuery = `%${queryString || ''}%`;
      const offset = (pageNo - 1) * limit;

      const whereCondition: any = {
        OR: [
          { email: { contains: searchQuery, mode: 'insensitive' } },
          { firstName: { contains: searchQuery, mode: 'insensitive' } },
          { lastName: { contains: searchQuery, mode: 'insensitive' } },
        ],
        AND: [{ deletedAt: null }],
      };

      const rolesFilter =
        query.roles && query.roles.length > 0
          ? query.roles
          : ['STAFF', 'RECRUITER', 'CANDIDATE'];

      whereCondition.AND.push({
        role: {
          in: rolesFilter,
        },
      });

      if (query.isApproved) {
        whereCondition.AND.push({ isApproved: true });
      } else {
        whereCondition.AND.push({ isApproved: false });
      }

      const totalCount = await this.databaseService.user.count({
        where: whereCondition,
      });

      const users = await this.databaseService.user.findMany({
        where: whereCondition,
        skip: offset,
        take: limit,
        orderBy: {
          [query?.sortedField || 'createdAt']:
            query?.sortedOrder?.toLocaleLowerCase() || 'asc',
        },
      });

      const totalPages = Math.ceil(totalCount / limit);
      const hasNextPage = pageNo < totalPages;

      return {
        success: true,
        message: 'Users retrieved successfully.',
        data: {
          users,
          hasNextPage,
          total: totalCount,
          next: hasNextPage ? pageNo + 1 : null,
        },
      };
    } catch (error) {
      this.logger.error('Error in getAllUsers:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async updateUserById(userId: string, updateUserDto: UpdateUserDto) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: { id: userId, deletedAt: null },
      });

      if (!user) {
        throw {
          name: 'notFound',
          message: 'User not found.',
        };
      }

      const updatedUser = await this.databaseService.user.update({
        where: { id: userId },
        data: {
          ...updateUserDto,
        },
      });

      return {
        success: true,
        message: 'User updated successfully.',
        data: updatedUser,
      };
    } catch (error) {
      this.logger.error('Error in updateUserById:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async deleteUserById(userId: string) {
    try {
      const user = await this.databaseService.user.findUnique({
        where: { id: userId, deletedAt: null },
      });

      if (!user) {
        throw {
          name: 'notFound',
          message: 'User not found.',
        };
      }

      const deletedUser = await this.databaseService.user.update({
        where: { id: userId },
        data: {
          deletedAt: new Date(),
        },
      });

      return {
        success: true,
        message: 'User deleted successfully.',
        data: deletedUser,
      };
    } catch (error) {
      this.logger.error('Error in deleteUserById:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async uploadResume(
    userId: string,
    file: Express.Multer.File,
    dto: UploadResumeDto,
  ) {
    let s3Key = '';
    try {
      s3Key = await this.s3Service.uploadImage(file, S3_FOLDER.RESUME, true);
      const resumeUrl = `${s3Key}`;
      const resume = await this.databaseService.resume.create({
        data: {
          title: dto.title,
          fileName: file.originalname,
          resumeUrl,
          userId,
        },
      });

      if (!resume) {
        throw {
          name: 'badRequest',
          message: 'Failed to upload resume.',
        };
      }

      return {
        success: true,
        message: 'Resume uploaded successfully.',
        data: resume,
      };
    } catch (error) {
      this.logger.error('Error in uploadResume:', error);
      // delete file from s3
      if (s3Key) {
        await this.s3Service.deleteFile(
          s3Key,
          process.env.SUPABASE_PRIVATE_BUCKET_NAME,
        );
      }
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }
  async updateResume(
    userId: string,
    file: Express.Multer.File,
    dto: UploadResumeDto,
    resumeId: string,
  ) {
    let resume;
    let s3Key = '';
    try {
      resume = await this.databaseService.resume.findFirst({
        where: {
          userId,
          id: resumeId,
          deletedAt: null,
        },
      });

      if (!resume) {
        throw {
          name: 'notFound',
          message: 'Resume not found.',
        };
      }
      const key = resume.resumeUrl || '';
      if (resume.resumeUrl) {
        try {
          await this.s3Service.deleteFile(
            key,
            process.env.SUPABASE_PRIVATE_BUCKET_NAME,
          );
        } catch (error) {
          this.logger.error('Error in updateResume:', error);
          return {
            success: false,
            message: error.message,
            data: error,
          };
        }
      }

      s3Key = await this.s3Service.uploadImage(file, S3_FOLDER.RESUME, true);
      const updatedResume = await this.databaseService.resume.update({
        where: { id: resumeId },
        data: {
          title: dto.title,
          fileName: file.originalname,
          resumeUrl: s3Key,
        },
      });

      if (!updatedResume) {
        throw {
          name: 'badRequest',
          message: 'Failed to update resume.',
        };
      }

      return {
        success: true,
        message: 'Resume updated successfully.',
        data: updatedResume,
      };
    } catch (error) {
      this.logger.error('Error in updateResume:', error);
      if (resume.resumeUrl) {
        await this.s3Service.deleteFile(
          s3Key,
          process.env.SUPABASE_PRIVATE_BUCKET_NAME,
        );
      }

      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }

  async deleteResume(userId: string, resumeId: string) {
    try {
      const resume = await this.databaseService.resume.findFirst({
        where: {
          userId,
          id: resumeId,
          deletedAt: null,
        },
      });

      if (!resume) {
        throw {
          name: 'notFound',
          message: 'Resume not found.',
        };
      }

      if (resume.resumeUrl) {
        try {
          await this.s3Service.deleteFile(
            resume.resumeUrl,
            process.env.SUPABASE_PRIVATE_BUCKET_NAME,
          );
        } catch (error) {
          this.logger.error('Error deleting file from S3:', error);
          return {
            success: false,
            message: error.message,
            data: error,
          };
        }
      }

      const deletedResume = await this.databaseService.resume.delete({
        where: { id: resumeId },
      });

      if (!deletedResume) {
        throw {
          name: 'badRequest',
          message: 'Failed to delete resume.',
        };
      }

      return {
        success: true,
        message: 'Resume deleted successfully.',
        data: deletedResume,
      };
    } catch (error) {
      this.logger.error('Error in deleteResume:', error);
      return {
        success: false,
        message: error.message || 'Failed to delete resume.',
        data: error,
      };
    }
  }

  async getResume(userId: string) {
    try {
      const resume = await this.databaseService.resume.findMany({
        where: {
          userId,
        },
      });

      // get presigned urls
      for (let i = 0; i < resume.length; i++) {
        resume[i].resumeUrl = await this.s3Service.getSignedUrl(
          resume[i].resumeUrl || '',
        );
      }

      return {
        success: true,
        message: 'Resume retrieved successfully.',
        data: resume,
      };
    } catch (error) {
      this.logger.error('Error in getResume:', error);
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }
  private async updateUserOtp(userId: string, otp: string) {
    const updateOtp = await this.databaseService.user.update({
      where: {
        id: userId,
      },
      data: {
        otp: otp.toString(),
      },
    });

    if (!updateOtp) {
      throw {
        name: 'badRequest',
        message: 'Failed to update OTP.',
      };
    }
  }
  private async sendOtpEmail(user: any, otp: string) {
    const otpSend = await this.emailService.emailOTP(user, otp);
    if (!otpSend) {
      throw {
        name: 'badRequest',
        message: 'Failed to send OTP.',
      };
    }
  }

  private async createUser(createUserDto: CreateUserDto, otp: string) {
    const hashedPassword = await this.generateHashedPassword(
      createUserDto.password,
    );
    createUserDto.password = hashedPassword;
    createUserDto.otp = otp;
    await this.databaseService.user.create({
      data: {
        ...createUserDto,
        email: createUserDto.email.toLocaleLowerCase(),
      },
    });
  }

  async generateHashedPassword(password: string) {
    const salt = await bcrypt.genSalt(10);
    return bcrypt.hash(password, salt);
  }
}
