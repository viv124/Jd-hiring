export const catchResponse = (error: any) => {
  return { success: false, message: error.message, data: error };
};
