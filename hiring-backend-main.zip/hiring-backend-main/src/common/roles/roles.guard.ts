import {
  CanActivate,
  ExecutionContext,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { Observable } from 'rxjs';
import { ROLES_KEY, RoleType } from './';
import { decodeToken } from 'src/utils/jwt.service';

@Injectable()
export class RolesGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(
    context: ExecutionContext,
  ): boolean | Promise<boolean> | Observable<boolean> {
    const roles = this.reflector.getAllAndOverride<RoleType[]>(ROLES_KEY, [
      context.getHandler(),
      context.getClass(),
    ]);

    if (!roles) {
      return true;
    }

    const req = context.switchToHttp().getRequest();
    if (!req.headers.authorization) {
      throw new UnauthorizedException('Authentication token missing');
    }

    const decoded = decodeToken(req.headers.authorization.split(' ')[1]);

    if (decoded && typeof decoded !== 'string' && decoded.role) {
      if (roles.some((role) => decoded.role.includes(role))) {
        return true;
      } else {
        throw new UnauthorizedException('Not allowed to access this resource.');
      }
    }

    throw new UnauthorizedException('Not allowed to access this resource.');
  }
}
