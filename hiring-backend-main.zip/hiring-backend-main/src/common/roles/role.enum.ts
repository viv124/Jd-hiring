import { Role } from '@prisma/client';

export enum RoleType {
  ADMIN = Role.ADMIN as any,
  STAFF = Role.STAFF as any,
  RECRUITER = Role.RECRUITER as any,
  CANDIDATE = Role.CANDIDATE as any,
}
