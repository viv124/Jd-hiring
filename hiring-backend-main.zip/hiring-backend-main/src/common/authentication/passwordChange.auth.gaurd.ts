import {
  Injectable,
  CanActivate,
  ExecutionContext,
  UnauthorizedException,
  Logger,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { DatabaseService } from 'src/database/database.service';

@Injectable()
export class PasswordChangeTokenGuard implements CanActivate {
  private readonly logger = new Logger('PasswordChangeTokenGuard');
  constructor(
    private readonly jwtService: JwtService,
    private readonly databaseService: DatabaseService,
  ) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const token = request.headers['authorization'];
    if (!token) {
      return false; // No token provided
    }
    try {
      const jwtSecret = process.env.PASSWORD_CHANGE_SECRET_KEY;
      if (!jwtSecret) {
        throw new Error('JWT_SECRET is not available');
      }
      const decoded = await this.jwtService.verifyAsync(
        token.replace('Bearer ', ''),
        {
          secret: jwtSecret,
        },
      );
      if (!decoded) {
        return false;
      }

      const user = await this.databaseService.user.findUnique({
        where: {
          email: decoded.email,
          resetToken: token,
          resetTokenExpiry: {
            gte: new Date(), // Check if the token is still valid
          },
          isVerified: true,
          deletedAt: null,
        },
      });

      if (!user) {
        throw new UnauthorizedException('Token already used or expired');
      }

      // If token is valid, attach the decoded payload to the request object
      request.user = decoded;
      return true;
    } catch (error) {
      this.logger.error('Token validation failed', error);
      throw new UnauthorizedException(error.message ?? 'Token is invalid!');
    }
  }
}
