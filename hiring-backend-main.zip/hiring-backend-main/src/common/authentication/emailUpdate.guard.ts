import {
  CanActivate,
  ExecutionContext,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { DatabaseService } from 'src/database/database.service';

@Injectable()
export class EmailUpdateTokenGuard implements CanActivate {
  private readonly logger = new Logger('EmailUpdateTokenGuard');
  constructor(
    private readonly jwtService: JwtService,
    private readonly databaseService: DatabaseService,
  ) {}
  async canActivate(context: ExecutionContext): Promise<boolean> {
    const request = context.switchToHttp().getRequest();
    const token = request.headers['authorization']?.split(' ')[1];
    if (!token) {
      return false;
    }
    try {
      const jwtSecret = process.env.EMAIL_UPDATE_SECRET_KEY;
      if (!jwtSecret) {
        this.logger.error('JWT_SECRET is not available');
        throw new Error('JWT_SECRET is not available');
      }
      const decoded = await this.jwtService.verifyAsync(
        token.replace('Bearer ', ''),
        {
          secret: jwtSecret,
        },
      );
      if (!decoded) {
        this.logger.error('Invalid token');
        return false;
      }

      const user = await this.databaseService.user.findUnique({
        where: { id: decoded.id, email: decoded.oldEmail },
      });
      if (!user) {
        this.logger.error('User not found or email mismatch');
        throw new UnauthorizedException('Token already used or expired');
      }
      request.user = decoded;
      return true;
    } catch (error) {
      this.logger.error('Error in emailUpdateTokenGuard:', error);
      return false;
    }
  }
}
