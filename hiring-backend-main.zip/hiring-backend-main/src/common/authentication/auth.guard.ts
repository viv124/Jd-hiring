import {
  CanActivate,
  ExecutionContext,
  Injectable,
  Logger,
  UnauthorizedException,
} from '@nestjs/common';
import { DatabaseService } from 'src/database/database.service';
import { decodeToken } from 'src/utils/jwt.service';
import { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken';

@Injectable()
export class AuthGuard implements CanActivate {
  private readonly logger = new Logger(AuthGuard.name);
  constructor(private readonly databaseService: DatabaseService) {}

  async canActivate(context: ExecutionContext): Promise<boolean> {
    const req = context.switchToHttp().getRequest();
    const token = this.extractToken(req);

    if (!token) {
      this.logger.warn('Authentication token missing');
      throw new UnauthorizedException('Authentication token missing');
    }

    try {
      const decoded = decodeToken(token);
      this.logger.debug('Token decoded successfully');

      if (decoded && typeof decoded !== 'string') {
        this.logger.debug('Decoded token payload:', decoded);

        const user = await this.databaseService.user.findUnique({
          where: { email: decoded.email, deletedAt: null },
        });

        if (user) {
          req.user = user;
          this.logger.debug(`User authenticated: ${user.email}`);
          return true;
        }
      }
      this.logger.warn('User not found for token');
      throw new UnauthorizedException('User not found');
    } catch (error) {
      if (error instanceof TokenExpiredError) {
        throw new UnauthorizedException('Token expired, please login again');
      } else if (error instanceof JsonWebTokenError) {
        throw new UnauthorizedException('Invalid authentication token');
      } else {
        throw new UnauthorizedException('Authentication error');
      }
    }
  }

  private extractToken(request): string | null {
    const authHeader = request.headers.authorization;
    return authHeader?.startsWith('Bearer ') ? authHeader.split(' ')[1] : null;
  }
}
