import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class QueryRequestInput {
  @ApiProperty({
    description: 'Filter by Invoice (case-insensitive)',
    example: '1',
    required: false,
  })
  @IsString()
  @IsOptional()
  queryString?: string;

  //sortedField optional
  @ApiProperty({
    example: 'createdAt',
    description: 'Sort by field',
    required: false,
  })
  @IsString()
  @IsOptional()
  sortedField?: string;

  //sortedOrder optional
  @ApiProperty({
    example: 'DESC',
    description: 'Sort by order',
    required: false,
  })
  @IsString()
  @IsOptional()
  sortedOrder?: 'ASC' | 'DESC' = 'ASC';

  @ApiProperty({
    example: 10,
    description: 'Limit the number of results per page',
    required: false,
  })
  @IsInt()
  @IsOptional()
  @Type(() => Number)
  limit?: number = 10;

  @ApiProperty({ example: 1, description: 'Page number', required: false })
  @IsInt()
  @IsOptional()
  @Type(() => Number)
  pageNo?: number = 1;
}
