import { Module } from '@nestjs/common';
import { JobDescriptionService } from './job-description.service';
import { JobDescriptionController } from './job-description.controller';
import { DatabaseModule } from 'src/database/database.module';
import { S3Service } from 'src/s3/s3.service';

@Module({
  imports: [DatabaseModule],
  controllers: [JobDescriptionController],
  providers: [JobDescriptionService, S3Service],
})
export class JobDescriptionModule {}
