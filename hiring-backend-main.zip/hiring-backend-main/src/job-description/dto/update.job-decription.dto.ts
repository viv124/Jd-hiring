import { ApiPropertyOptional } from '@nestjs/swagger';
import { IsOptional, IsInt, IsEmail } from 'class-validator';
import { ExperienceLevel, JobType, WorkStyle } from '@prisma/client';
import { Type } from 'class-transformer';

export class UpdateJobDescriptionDto {
  @ApiPropertyOptional({
    description: 'Job title',
    example: 'Software Engineer (Backend)',
  })
  @IsOptional()
  title?: string;

  @ApiPropertyOptional({ description: 'Company name', example: 'TechCorp' })
  @IsOptional()
  companyName?: string;

  @ApiPropertyOptional({
    description: 'Job location',
    example: 'Bangalore, India',
  })
  @IsOptional()
  location?: string;

  @ApiPropertyOptional({
    description: 'Job description',
    example: 'Backend development...',
  })
  @IsOptional()
  description?: string;

  @ApiPropertyOptional({ description: 'Minimum salary', example: 80000 })
  @IsOptional()
  @IsInt()
  @Type(() => Number)
  salaryLow?: number;

  @ApiPropertyOptional({ description: 'Maximum salary', example: 120000 })
  @IsOptional()
  @IsInt()
  @Type(() => Number)
  salaryHigh?: number;

  @ApiPropertyOptional({ description: 'Tags', example: 'Node.js, PostgreSQL' })
  @IsOptional()
  tags?: string;

  @ApiPropertyOptional({
    enum: JobType,
    description: 'Type of job',
    example: 'FULL_TIME',
  })
  @IsOptional()
  jobType?: JobType;

  @ApiPropertyOptional({
    enum: ExperienceLevel,
    description: 'Experience level',
    example: 'MID_LEVEL',
  })
  @IsOptional()
  experienceLevel?: ExperienceLevel;

  @ApiPropertyOptional({
    enum: WorkStyle,
    description: 'Work style',
    example: 'HYBRID',
  })
  @IsOptional()
  workStyle?: WorkStyle;

  @ApiPropertyOptional({ description: 'Number of job openings', example: 5 })
  @IsOptional()
  @IsInt()
  @Type(() => Number)
  openings?: number;

  @ApiPropertyOptional({
    description: 'Application deadline',
    type: String,
    format: 'date-time',
    example: '2025-08-25T04:37:00Z',
  })
  @IsOptional()
  @Type(() => Date)
  applicationDeadline?: Date;

  @ApiPropertyOptional({
    description: 'Contact email',
    example: 'hr@techcorp.com',
  })
  @IsOptional()
  @IsEmail()
  contactEmail?: string;

  @ApiPropertyOptional({
    description: 'Skills required',
    example: 'Node.js, PostgreSQL',
  })
  @IsOptional()
  skillsRequired?: string;

  @ApiPropertyOptional({ description: 'Is the job active?', example: true })
  @IsOptional()
  isActive?: boolean;
}
