import { IsInt, IsNotEmpty, IsOptional } from 'class-validator';
import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { ExperienceLevel, JobType, WorkStyle } from '@prisma/client';
import { Type } from 'class-transformer';

export class CreateJobDescriptionDto {
  @ApiProperty({
    description: 'Job title',
    example: 'Software Engineer (Backend)',
  })
  @IsNotEmpty()
  title: string;

  @ApiProperty({ description: 'Company name', example: 'TechCorp' })
  @IsNotEmpty()
  companyName: string;

  @ApiProperty({ description: 'Job location', example: 'Bangalore, India' })
  @IsNotEmpty()
  location: string;

  @ApiProperty({
    description: 'Job description',
    example:
      'We are seeking a skilled Software Engineer with expertise in backend development...',
  })
  @IsNotEmpty()
  description: string;

  @ApiProperty({ description: 'Minimum salary', example: 80000 })
  @IsInt()
  @Type(() => Number)
  @IsNotEmpty()
  salaryLow: number;

  @ApiProperty({ description: 'Maximum salary', example: 120000 })
  @IsInt()
  @IsNotEmpty()
  @Type(() => Number)
  salaryHigh: number;

  //tags string
  @ApiProperty({
    description: 'Tags',
    example: 'Node.js, PostgreSQL, API Design',
  })
  @IsOptional()
  tags?: string;

  @ApiProperty({
    enum: JobType,
    description: 'Type of job',
    example: 'FULL_TIME',
  })
  @IsNotEmpty()
  jobType: JobType;

  @ApiProperty({
    enum: ExperienceLevel,
    description: 'Experience level required',
    example: 'MID_LEVEL',
  })
  @IsNotEmpty()
  experienceLevel: ExperienceLevel;

  @ApiProperty({
    enum: WorkStyle,
    description: 'Work style',
    example: 'HYBRID',
  })
  @IsNotEmpty()
  workStyle: WorkStyle;

  @ApiProperty({
    description: 'Number of job openings',
    example: 5,
  })
  @IsInt()
  @IsNotEmpty()
  @Type(() => Number)
  openings: number;

  @ApiPropertyOptional({
    description: 'Application deadline',
    type: String,
    format: 'date-time',
    example: '2025-08-25T04:37:00Z',
  })
  @IsOptional()
  applicationDeadline?: Date;

  @ApiPropertyOptional({
    description: 'Contact email',
    example: 'hr@techcorp.com',
  })
  @IsOptional()
  contactEmail?: string;

  @ApiProperty({
    description: 'Skills required',
    example: 'Node.js, PostgreSQL, API Design',
  })
  @IsOptional()
  skillsRequired?: string;

  @IsOptional()
  postUrl?: string;

  @ApiPropertyOptional({ description: 'Is the job active?', example: true })
  @IsOptional()
  isActive?: boolean;

  @ApiPropertyOptional({ type: 'string', format: 'binary' })
  file?: any; // This will represent the uploaded file
}
