import { ApiProperty } from '@nestjs/swagger';
import { IsInt, IsOptional, IsString } from 'class-validator';
import { Type } from 'class-transformer';

export class QueryRequestInputJob {
  @ApiProperty({
    description: 'Filter by Invoice (case-insensitive)',
    example: '',
    required: false,
  })
  @IsString()
  @IsOptional()
  queryString?: string;

  //location optional
  @ApiProperty({
    description: 'Filter by location (case-insensitive)',
    example: 'bangalore',
    required: false,
  })
  @IsString()
  @IsOptional()
  location?: string;

  //jobtype optional
  @ApiProperty({
    description: 'Filter by job type',
    example: 'FULL_TIME,PART_TIME,CONTRACT,INTERNSHIP',
    required: false,
  })
  @IsString()
  @IsOptional()
  jobType?: string;

  //experienceLevel optional
  @ApiProperty({
    description: 'Filter by experience level',
    example: ' ENTRY_LEVEL,MID_LEVEL,SENIOR,EXECUTIVE',
    required: false,
  })
  @IsString()
  @IsOptional()
  experienceLevel?: string;

  //workStyle optional
  @ApiProperty({
    description: 'Filter by work style',
    example: 'HYBRID,REMOTE,ONSITE,',
    required: false,
  })
  @IsString()
  @IsOptional()
  workStyle?: string;

  //sortedField optional
  @ApiProperty({
    example: 'createdAt',
    description: 'Sort by field',
    required: false,
  })
  @IsString()
  @IsOptional()
  sortedField?: string;

  //sortedOrder optional
  @ApiProperty({
    example: 'desc',
    description: 'Sort by order',
    required: false,
  })
  @IsString()
  @IsOptional()
  sortedOrder?: 'asc' | 'desc' = 'asc';

  @ApiProperty({
    example: 10,
    description: 'Limit the number of results per page',
    required: false,
  })
  @IsInt()
  @IsOptional()
  @Type(() => Number)
  limit?: number = 10;

  @ApiProperty({ example: 1, description: 'Page number', required: false })
  @IsInt()
  @IsOptional()
  @Type(() => Number)
  pageNo?: number = 1;
}
