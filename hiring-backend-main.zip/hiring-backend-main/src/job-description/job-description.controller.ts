import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Post,
  Put,
  Query,
  Req,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { JobDescriptionService } from './job-description.service';

import {
  ApiTags,
  ApiOperation,
  ApiBody,
  ApiConsumes,
  ApiBearerAuth,
} from '@nestjs/swagger';
import { CreateJobDescriptionDto } from './dto/create.job-description.dto';
import { ResponseError, ResponseSuccess } from 'src/common/dto/response.dto';
import { FileInterceptor } from '@nestjs/platform-express';
import { AuthGuard } from 'src/common/authentication/auth.guard';
import { QueryRequestInputJob } from './dto/job-pagination.dto';
import { Roles, RolesGuard, RoleType } from 'src/common/roles';
import { UpdateJobDescriptionDto } from './dto/update.job-decription.dto';
@ApiTags('Job Description Module')
@Controller('job-description')
export class JobDescriptionController {
  constructor(private readonly jobDescriptionService: JobDescriptionService) {}

  @Post()
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.ADMIN, RoleType.RECRUITER, RoleType.STAFF)
  @UseInterceptors(FileInterceptor('file'))
  @ApiOperation({ summary: 'Create a new job with optional file upload' })
  @ApiConsumes('multipart/form-data')
  @ApiBody({
    description: 'Job data and optional file',
    schema: {
      type: 'object',
      properties: {
        title: { type: 'string', example: 'Software Engineer (Backend)' },
        companyName: { type: 'string', example: 'TechCorp' },
        location: { type: 'string', example: 'Bangalore, India' },
        description: { type: 'string', example: 'Backend job description...' },
        salaryLow: { type: 'integer', example: 80000 },
        salaryHigh: { type: 'integer', example: 120000 },
        tags: { type: 'string', example: 'nodejs,prisma' },
        jobType: { type: 'string', example: 'FULL_TIME' },
        experienceLevel: { type: 'string', example: 'MID_LEVEL' },
        workStyle: { type: 'string', example: 'HYBRID' },
        openings: { type: 'integer', example: 5 },
        applicationDeadline: {
          type: 'string',
          format: 'date-time',
          example: '2025-08-25T04:37:00Z',
        },
        contactEmail: { type: 'string', example: 'hr@techcorp.com' },
        skillsRequired: {
          type: 'string',
          example: 'nodejs,prisma',
        },
        file: {
          type: 'string',
          format: 'binary',
          description: 'Optional file upload',
        },
      },
      required: [
        'title',
        'companyName',
        'location',
        'description',
        'salaryLow',
        'salaryHigh',
        'jobType',
        'experienceLevel',
        'workStyle',
        'openings',
      ],
    },
  })
  async create(
    @Req() req: any,
    @Body() createJobDescriptionDto: CreateJobDescriptionDto,
    @UploadedFile() file?: Express.Multer.File,
  ) {
    const result = await this.jobDescriptionService.create(
      createJobDescriptionDto,
      file,
      req.user,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  //get api to get all job descriptions with pagination
  @Get()
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard)
  @ApiOperation({ summary: 'Get all job descriptions with pagination' })
  async getAllJobDescriptions(
    @Req() req: any,
    @Query() query: QueryRequestInputJob,
  ) {
    const result = await this.jobDescriptionService.getAllJobDescriptions(
      req.user,
      query,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @Put(':id')
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.ADMIN, RoleType.RECRUITER, RoleType.STAFF)
  @ApiOperation({ summary: 'Update job description (without file upload)' })
  async updateJobDescription(
    @Param('id') id: string,
    @Body() updateJobDescriptionDto: UpdateJobDescriptionDto,
  ) {
    const result = await this.jobDescriptionService.update(
      id,
      updateJobDescriptionDto,
    );
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }

  @Delete(':id')
  @ApiBearerAuth('Authorization')
  @UseGuards(AuthGuard, RolesGuard)
  @Roles(RoleType.ADMIN, RoleType.RECRUITER, RoleType.STAFF)
  @ApiOperation({ summary: 'Delete a job description by ID' })
  async deleteJobDescription(@Param('id') id: string) {
    const result = await this.jobDescriptionService.delete(id);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return new ResponseSuccess(result.data, result.message).getResponse();
  }
}
