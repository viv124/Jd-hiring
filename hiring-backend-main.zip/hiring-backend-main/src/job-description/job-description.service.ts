import { Injectable, Logger } from '@nestjs/common';
import { DatabaseService } from 'src/database/database.service';
import { S3Service } from 'src/s3/s3.service';
import { CreateJobDescriptionDto } from './dto/create.job-description.dto';
import { S3_FOLDER } from 'src/helper/helperService';
import { QueryRequestInputJob } from './dto/job-pagination.dto';
import { JobType } from '@prisma/client';
import { UpdateJobDescriptionDto } from './dto/update.job-decription.dto';

@Injectable()
export class JobDescriptionService {
  private readonly logger = new Logger(JobDescriptionService.name);
  constructor(
    private readonly databaseService: DatabaseService,
    private readonly s3Service: S3Service,
  ) {}

  async create(
    createJobDescriptionDto: CreateJobDescriptionDto,
    file?: Express.Multer.File,
    user?: any, // Assuming user is passed from the controller
  ) {
    try {
      this.logger.log(
        'Creating job description with data:',
        createJobDescriptionDto,
      );

      // Handle file upload if provided
      let fileUrl: string | null = null;
      if (file) {
        fileUrl = await this.s3Service.uploadImage(
          file,
          S3_FOLDER.JOB_DESCRIPTION,
        );
        createJobDescriptionDto.postUrl = `${process.env.SUPABASE_PUBLIC_BUCKET_URL}/${fileUrl}`;
      }
      delete createJobDescriptionDto.file;

      // Save job description to the database
      const jobDescription = await this.databaseService.jobDescription.create({
        data: {
          ...createJobDescriptionDto,
          createdBy: user?.id || null, // Assuming user ID is available
        },
      });

      this.logger.log('Job description created successfully:', jobDescription);
      return {
        success: true,
        message: 'Job description created successfully.',
        data: jobDescription,
      };
    } catch (error) {
      this.logger.error('Error in createJobDescription:', error);
      return {
        success: false,
        message: error.message || 'Failed to create job description.',
        data: error,
      };
    }
  }

  async getAllJobDescriptions(user: any, query: QueryRequestInputJob) {
    try {
      const { pageNo = 1, limit = 10, queryString } = query;
      const searchQuery = `%${queryString || ''}%`;
      const offset = (pageNo - 1) * limit;
      const whereCondition: any = {
        OR: [
          { title: { contains: searchQuery, mode: 'insensitive' } },
          { companyName: { contains: searchQuery, mode: 'insensitive' } },
          { location: { contains: searchQuery, mode: 'insensitive' } },
          { description: { contains: searchQuery, mode: 'insensitive' } },
          {
            tags: { contains: searchQuery, mode: 'insensitive' },
          },
          {
            skillsRequired: { contains: searchQuery, mode: 'insensitive' },
          },
        ],
        AND: [{ deletedAt: null }, { isActive: true }],
      };

      if (query.jobType) {
        whereCondition.AND.push({ jobType: query.jobType as JobType });
      }
      if (query.experienceLevel) {
        whereCondition.AND.push({ experienceLevel: query.experienceLevel });
      }
      if (query.workStyle) {
        whereCondition.AND.push({ workStyle: query.workStyle });
      }

      if (query.location) {
        whereCondition.AND.push({
          location: { contains: query.location, mode: 'insensitive' },
        });
      }

      const totalCount = await this.databaseService.jobDescription.count({
        where: whereCondition,
      });
      const jobDescriptions =
        await this.databaseService.jobDescription.findMany({
          where: whereCondition,
          skip: offset,
          take: limit,
          orderBy: {
            [query.sortedField || 'createdAt']:
              query.sortedOrder?.toLocaleLowerCase() || 'asc',
          },
        });

      const totalPages = Math.ceil(totalCount / limit);
      const hasNextPage = pageNo < totalPages;

      this.logger.log('Job descriptions fetched successfully');
      return {
        success: true,
        message: 'Job descriptions fetched successfully.',
        data: {
          jobDescriptions,
          hasNextPage,
          total: totalCount,
          next: hasNextPage ? pageNo + 1 : null,
        },
      };
    } catch (error) {
      this.logger.error('Error in getAllJobDescriptions:', error);
      return {
        success: false,
        message: error.message || 'Failed to fetch job descriptions.',
        data: error,
      };
    }
  }

  async update(id: string, updateJobDescriptionDto: UpdateJobDescriptionDto) {
    try {
      this.logger.log('Updating job description id:', id);

      const existingJob = await this.databaseService.jobDescription.findUnique({
        where: { id },
      });

      if (!existingJob) {
        throw {
          name: 'notFound',
          message: 'Job description not found.',
        };
      }

      const updatedJob = await this.databaseService.jobDescription.update({
        where: { id },
        data: {
          ...updateJobDescriptionDto,
          updatedAt: new Date(),
        },
      });

      this.logger.log('Job description updated');

      return {
        success: true,
        message: 'Job description updated successfully.',
        data: updatedJob,
      };
    } catch (error) {
      this.logger.error('Error updating job description:', error);
      return {
        success: false,
        message: error.message || 'Failed to update job description.',
        data: error,
      };
    }
  }

  async delete(id: string) {
    try {
      const existingJob = await this.databaseService.jobDescription.findUnique({
        where: { id },
      });

      if (!existingJob) {
        throw {
          name: 'notFound',
          message: 'Job description not found.',
        };
      }

      const deletedJob = await this.databaseService.jobDescription.update({
        where: { id },
        data: {
          deletedAt: new Date(),
        },
      });

      return {
        success: true,
        message: 'Job description deleted successfully.',
        data: deletedJob,
      };
    } catch (error) {
      this.logger.error('Error deleting job description:', error);
      return {
        success: false,
        message: error.message || 'Failed to delete job description.',
        data: error,
      };
    }
  }
}
