import { ApiProperty } from '@nestjs/swagger';
import { Role } from '@prisma/client';

import { IsEmail, IsEnum, IsString } from 'class-validator';

export class CreateGoogleDto {
  @IsString()
  @IsEmail()
  @ApiProperty({ example: 'user.jd@yopmail.com', description: 'email' })
  email: string;

  @IsString()
  @ApiProperty({ example: 'jd user', description: 'first name' })
  firstName: string;

  @IsString()
  @ApiProperty({ example: 'doe', description: 'last name' })
  lastName: string;

  @ApiProperty({
    enum: Role,
    example: 'ADMIN,STAFF,RECRUITER',
  })
  @IsEnum(Role, {
    message: 'Invalid Role. Must be one of: ADMIN,USER',
  })
  role: Role;
}
