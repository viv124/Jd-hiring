import { Module } from '@nestjs/common';
import { GoogleAuthService } from './google-auth.service';
import { GoogleAuthController } from './google-auth.controller';
import { PassportModule } from '@nestjs/passport';
import { GoogleStrategy } from './google.strategy';
import { SessionSerializer } from './passport.serializer';
import { DatabaseService } from 'src/database/database.service';
import { DatabaseModule } from 'src/database/database.module';
@Module({
  imports: [PassportModule.register({ session: false }), DatabaseModule],
  providers: [
    GoogleAuthService,
    GoogleStrategy,
    SessionSerializer,
    DatabaseService,
  ],
  controllers: [GoogleAuthController],
  exports: [GoogleAuthService],
})
export class GoogleAuthModule {}
