import { Injectable } from '@nestjs/common';
import { DatabaseService } from 'src/database/database.service';
import { createToken } from 'src/utils/jwt.service';
import { Role } from '@prisma/client';
import { CreateGoogleDto } from './Dto/google-register.dto';

@Injectable()
export class GoogleAuthService {
  constructor(private readonly databaseService: DatabaseService) {}

  async registerUser(createGoogleDto: CreateGoogleDto) {
    try {
      const userCheck = await this.databaseService.user.findUnique({
        where: {
          email: createGoogleDto.email.toLocaleLowerCase(),
          deletedAt: null,
        },
      });

      let result;
      if (userCheck) {
        if (!userCheck.isVerified) {
          result = await this.databaseService.user.update({
            where: { id: userCheck.id },
            data: {
              firstName: createGoogleDto.firstName,
              lastName: createGoogleDto.lastName,
              isVerified: true,
              isApproved: true,
            },
          });
        } else {
          result = userCheck;
        }
      } else {
        result = await this.databaseService.user.create({
          data: {
            firstName: createGoogleDto.firstName,
            lastName: createGoogleDto.lastName,
            email: createGoogleDto.email.toLocaleLowerCase(),
            role: Role.CANDIDATE,
            isVerified: true,
            isApproved: true,
          },
        });
      }
      const accessToken = createToken(
        result.firstName + ' ' + result.lastName,
        result.email,
        result.role,
      );
      return {
        success: true,
        message: 'Login successfully.',
        data: {
          accessToken,
        },
      };
    } catch (error) {
      return {
        success: false,
        message: error.message,
        data: error,
      };
    }
  }
}
