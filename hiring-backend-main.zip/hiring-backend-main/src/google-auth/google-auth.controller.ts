import { Controller, Get, Req, Res, UseGuards } from '@nestjs/common';
import { GoogleAuthGuard } from '../guard/google-auth';
import { Response } from 'express';
import { GoogleAuthService } from './google-auth.service';
import { ResponseError } from 'src/common/dto/response.dto';
import { ApiTags } from '@nestjs/swagger';
@ApiTags('Google Auth Module')
@Controller('auth')
export class GoogleAuthController {
  constructor(private readonly googleAuthService: GoogleAuthService) {}

  @Get('google')
  @UseGuards(GoogleAuthGuard)
  googleAuth() {
    // Initiates Google OAuth2 login
    return { message: 'Google OAuth2 login initiated' };
  }

  @Get('google/redirect')
  @UseGuards(GoogleAuthGuard)
  async googleAuthRedirect(@Req() req, @Res() res: Response) {
    const result = await this.googleAuthService.registerUser(req.user);
    if (!result.success) {
      return new ResponseError(result.data, result.message).getResponse();
    }
    return res.redirect(
      `${process.env.FRONTEND_REDIRECT_URL}?token=${result.data.accessToken.access_token}`,
    );
  }
}
