=====

1. first git pull

2. env setup

3. npm install

4. npx prisma generate
